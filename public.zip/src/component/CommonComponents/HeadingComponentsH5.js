import React from 'react'

const HeadingComponentsH5 = ({ headingH5 }) => {
    return (
        <h5>{headingH5}</h5>
    )
}
export default HeadingComponentsH5