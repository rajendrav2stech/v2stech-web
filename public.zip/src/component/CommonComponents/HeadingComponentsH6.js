import React from 'react'

const HeadingComponentsH6 = ({ headingH6 }) => {
    return (
        <h6>{headingH6}</h6>
    )
}
export default HeadingComponentsH6