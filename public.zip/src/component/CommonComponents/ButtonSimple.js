import React from 'react'
import { Link } from 'react-router-dom';

const ButtonSimple = ({ content }) => {
    return (
        <button>{content}</button>
    )
}
export default ButtonSimple;