import React from 'react'

const HeadingComponentsH3 = ({ headingH3 }) => {
    return (
        <h4>{headingH3}</h4>
    )
}
export default HeadingComponentsH3