import React from 'react'

const ParagraphComponent = ({ content }) => {
    return (
        <p>{content}</p>
    )
}
export default ParagraphComponent