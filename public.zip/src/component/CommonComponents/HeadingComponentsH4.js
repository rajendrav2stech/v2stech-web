import React from 'react'

const HeadingComponentsH4 = ({ headingH4 }) => {
    return (
        <h4>{headingH4}</h4>
    )
}
export default HeadingComponentsH4