import React from 'react'

export default class AboutIndustryExperienceDetails extends React.Component {
    render() {
        return (
            <>
                <div className="about_industry_experience_details">
                    
                </div>
            </>
        )
    }
}