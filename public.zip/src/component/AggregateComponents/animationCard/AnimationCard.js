import { render } from '@testing-library/react'
import React from 'react'
export default class AnimationCard extends React.Component {
    render() {
        return (
            <>
                
            </>
        )
    }
}