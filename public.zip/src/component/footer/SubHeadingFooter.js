import React from 'react'

function SubHeadingFooter({ content }) {
    return (
        <h4>{content}</h4>
    )
}
export default SubHeadingFooter