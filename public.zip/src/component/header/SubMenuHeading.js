import React from 'react'

function SubMenuHeading({ content }) {
    return (
        <h5>{content}</h5>
    )
}
export default SubMenuHeading