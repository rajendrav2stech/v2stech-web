import React from 'react'
// import News from './News'

function contactUs() {
    return (
        <>
            <ContactUsPage />
        </>
    )
}
export default contactUs