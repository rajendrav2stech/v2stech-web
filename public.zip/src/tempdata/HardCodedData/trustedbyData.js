//  Trusted by details :: image/icon , redirect url
export const trustedbyData = [
    {
        image: "image1",
        redirectUrl: "/redirect1",
    },
    {
        image: "image2",
        redirectUrl: "/redirect2",
    },
    {
        image: "image3",
        redirectUrl: "/redirect3",
    },
]